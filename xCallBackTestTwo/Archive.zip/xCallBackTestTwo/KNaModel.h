//
//  knaModel.h
//  xCallBackTestTwo
//
//  Created by Harman on 18/01/17.
//  Copyright © 2017 Harman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KNaModel : NSObject
    
    @property(strong,nonatomic)NSString *potassium;
    @property(strong,nonatomic)NSString *sodium;

@end
